# Netclone 
Clone da interface gráfica da Netflix utilizando apenas Python e Kivy. 
 - Video explicativo no YouTube: https://www.youtube.com/watch?v=d4_atvdQ9g8
- Requisitos: Python 3.7, Kivy e suas dependências(https://kivy.org/doc/stable/gettingstarted/installation.html)
- O que aprendi: Desenvolvimento de um aplicativo com interface gráfica dinâmica com Python (Kivy) e integrar diversas ferramentas que o 
Kivy oferece. Introdução ao desenvolvimento Mobile com Python (Kivy).

A página Content controla o conteúdo do aplicativo, o nome das pastas são as categorias do Menu e as images dentro delas são o conteúdo da 
categoria. Apertar f5 irá atualizar o aplicativo com as modificações feitas (copiar, mover, excluir e adicionar novas pastas(categorias) e/ou imagens(conteúdo das categorias)) dentro do Content.
